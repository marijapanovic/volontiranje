/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controllers;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import beans.Film;
import static com.sun.javafx.logging.PulseLogger.addMessage;
import java.awt.event.ActionEvent;
import java.util.List;
import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;
/**
 *
 * @author Korisnik
 */
@ManagedBean
@SessionScoped
public class Obrisi {
    private String naziv;

    public String getNaziv() {
        return naziv;
    }

    public void setNaziv(String naziv) {
        this.naziv = naziv;
    }
    private int idF;

    public int getIdF() {
        return idF;
    }

    public void setIdF(int idF) {
        this.idF = idF;
    }
    
    private Film selektovanFilm;

    public Film getSelektovanFilm() {
        return selektovanFilm;
    }

    public void setSelektovanFilm(Film selektovanFilm) {
        this.selektovanFilm = selektovanFilm;
    }
     public String obrisiFilm(){
        try {
            Connection con = DriverManager.getConnection(db.DB.connectionString, db.DB.user, db.DB.password);
            Statement stm = con.createStatement();
            stm.executeUpdate("delete from film where idF="+selektovanFilm.getIdF());
            
           
        } catch (SQLException ex) {
            Logger.getLogger(Obrisi.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;
    }
    
   
    
    
   
    List<Film> sviFilmovi;

    public List<Film> getSviFilmovi() {
        return sviFilmovi;
    }

    public void setSviFilmovi(List<Film> sviFilmovi) {
        this.sviFilmovi = sviFilmovi;
    }
        private void obrisiPoId(int idF){
            for(int i=0;i<sviFilmovi.size();i++){
                if(sviFilmovi.get(i).getIdF()==idF){
                    sviFilmovi.remove(i);
                    break;
                }
            }
        } 
  
   
    
   
}
