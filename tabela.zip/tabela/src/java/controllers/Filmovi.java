/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controllers;

import beans.Film;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;

/**
 *
 * @author Korisnik
 */
@ManagedBean
@SessionScoped
public class Filmovi {
      private List<Film> sviFilmovi;
private List<Film> sviNazivi;

    public List<Film> getSviNazivi() {
        return sviNazivi;
    }

    public void setSviNazivi(List<Film> sviNazivi) {
        this.sviNazivi = sviNazivi;
    }


    public List<Film> getSviFilmovi() {
        return sviFilmovi;
    }

    public void setSviFilmovi(List<Film> sviFilmovi) {
        this.sviFilmovi = sviFilmovi;
    }
    private int idF;

    public int getIdF() {
        return idF;
    }

    public void setIdF(int idF) {
        this.idF = idF;
    }
    

    public String dohvatiFilmove(){
        try {
            Connection conn = DriverManager.getConnection(db.DB.connectionString, db.DB.user, db.DB.password);
            Statement stm = conn.createStatement();
            ResultSet rs = stm.executeQuery("select * from film");
            sviFilmovi = new ArrayList<Film>();
            while(rs.next()){
                Film film = new Film();
                film.setIdF(rs.getInt("idF"));
                film.setNaziv(rs.getString("naziv"));
                film.setZanr(rs.getString("zanr"));
                film.setDuzinaTrajanja(rs.getInt("dazina_trajanja"));
                
                sviFilmovi.add(film);
                
            }
        } catch (SQLException ex) {
            Logger.getLogger(Filmovi.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;
    }
    
        
        
        
    
}
